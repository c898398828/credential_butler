(() => {
  "use strict";

  const {
    LOGIN_URL,
    STORAGE_KEY,
    MESSAGE,
    normalizeSettings,
    validateSettings,
    isLoginUrl,
  } = globalThis.ICBCAutofill;

  const form = document.getElementById("settings-form");
  const fields = document.getElementById("settings-fields");
  const enterpriseId = document.getElementById("enterprise-id");
  const username = document.getElementById("username");
  const password = document.getElementById("password");
  const enabled = document.getElementById("enabled");
  const togglePassword = document.getElementById("toggle-password");
  const saveButton = document.getElementById("save-button");
  const fillButton = document.getElementById("fill-button");
  const status = document.getElementById("form-status");
  const openLogin = document.getElementById("open-login");
  const clearButton = document.getElementById("clear-button");
  const confirmation = document.getElementById("clear-confirmation");
  const cancelClear = document.getElementById("cancel-clear");
  const confirmClear = document.getElementById("confirm-clear");

  const inputFields = [enterpriseId, username, password];
  const validationFields = new Map([
    ["请输入企业编号。", enterpriseId],
    ["企业编号最多为 8 位。", enterpriseId],
    ["请输入账号。", username],
    ["请输入密码。", password],
  ]);

  let savedSettings = normalizeSettings(undefined);
  let hasSavedSettings = false;
  let ready = false;
  let busy = false;

  function showStatus(message, kind = "neutral") {
    status.textContent = message;
    status.dataset.kind = kind;
  }

  function readForm() {
    return normalizeSettings({
      enterpriseId: enterpriseId.value,
      username: username.value,
      password: password.value,
      enabled: enabled.checked,
    });
  }

  function writeForm(settings) {
    enterpriseId.value = settings.enterpriseId;
    username.value = settings.username;
    password.value = settings.password;
    enabled.checked = settings.enabled;
    password.type = "password";
    togglePassword.textContent = "显示";
    togglePassword.setAttribute("aria-label", "显示密码");
    togglePassword.setAttribute("aria-pressed", "false");
  }

  function hasUnsavedChanges() {
    const current = readForm();
    return Object.keys(current).some((key) => current[key] !== savedSettings[key]);
  }

  function setBusy(value) {
    busy = value;
    fields.disabled = !ready || busy;
    clearButton.disabled = !ready || busy || !hasSavedSettings;
    cancelClear.disabled = busy;
    confirmClear.disabled = busy;
    form.setAttribute("aria-busy", String(busy));
  }

  function clearFieldError(input) {
    input.removeAttribute("aria-invalid");
    const message = document.getElementById(`${input.id}-error`);
    message.textContent = "";
    message.hidden = true;
  }

  function clearFieldErrors() {
    inputFields.forEach(clearFieldError);
  }

  function showValidationError(message) {
    clearFieldErrors();
    const input = validationFields.get(message);
    if (input) {
      input.setAttribute("aria-invalid", "true");
      const fieldError = document.getElementById(`${input.id}-error`);
      fieldError.textContent = message;
      fieldError.hidden = false;
      input.focus();
    }
    showStatus(message, "error");
  }

  function hideConfirmation() {
    confirmation.hidden = true;
    clearButton.hidden = false;
  }

  async function loadSettings() {
    try {
      const stored = await chrome.storage.local.get(STORAGE_KEY);
      hasSavedSettings = Object.prototype.hasOwnProperty.call(stored, STORAGE_KEY);
      savedSettings = normalizeSettings(stored[STORAGE_KEY]);
      writeForm(savedSettings);
      ready = true;
      setBusy(false);
      showStatus(hasSavedSettings
        ? "已读取已保存的默认信息。"
        : "填写信息后保存，即可自动填入登录页。");
    } catch {
      showStatus("无法读取本地设置，请关闭弹窗后重试。", "error");
    }
  }

  form.addEventListener("input", (event) => {
    if (!ready || busy) return;
    if (inputFields.includes(event.target)) clearFieldError(event.target);
    hideConfirmation();
    showStatus(hasUnsavedChanges()
      ? "设置有修改，请先保存。"
      : hasSavedSettings
        ? "已恢复为已保存的设置。"
        : "填写信息后保存，即可自动填入登录页。");
  });

  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    if (!ready || busy) return;
    hideConfirmation();

    const settings = readForm();
    const error = validateSettings(settings);
    if (error) {
      showValidationError(error);
      return;
    }

    clearFieldErrors();
    setBusy(true);
    showStatus("正在保存…");
    try {
      await chrome.storage.local.set({ [STORAGE_KEY]: settings });
      savedSettings = settings;
      hasSavedSettings = true;
      writeForm(settings);
      showStatus(settings.enabled
        ? "已保存。打开登录页时会自动填写。"
        : "已保存，自动填写已关闭。", "success");
    } catch {
      showStatus("保存失败，请稍后重试。", "error");
    } finally {
      setBusy(false);
    }
  });

  togglePassword.addEventListener("click", () => {
    const isVisible = password.type === "password";
    password.type = isVisible ? "text" : "password";
    togglePassword.textContent = isVisible ? "隐藏" : "显示";
    togglePassword.setAttribute("aria-label", isVisible ? "隐藏密码" : "显示密码");
    togglePassword.setAttribute("aria-pressed", String(isVisible));
  });

  function showFillResult(result) {
    if (result?.ok && result.status === "filled") {
      showStatus("已填写企业编号、账号和密码。", "success");
      return;
    }
    if (result?.ok && result.status === "already-filled") {
      showStatus("当前页面已填好保存的信息。", "success");
      return;
    }

    const messages = {
      "wrong-page": "请切换到财资云的账号登录页后再试。",
      "missing-fields": "暂未找到完整的登录表单，请等待页面加载后再试。",
      unconfigured: "请先保存完整的登录信息。",
      "storage-error": "无法读取本地设置，请稍后重试。",
      "user-edited": "页面内容或设置刚刚发生变化，填写已停止。请确认后再试。",
      conflict: "页面已有其他登录信息。请清空三个登录框后再试。",
    };
    showStatus(messages[result?.status] || "暂时无法填写，请刷新登录页后再试。", "error");
  }

  fillButton.addEventListener("click", async () => {
    if (!ready || busy) return;
    hideConfirmation();

    if (hasUnsavedChanges()) {
      showStatus("请先保存修改，再填写当前页面。", "error");
      saveButton.focus();
      return;
    }
    const error = validateSettings(savedSettings);
    if (error) {
      showValidationError(error);
      return;
    }

    setBusy(true);
    showStatus("正在填写当前页面…");
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (typeof tab?.id !== "number" || !isLoginUrl(tab.url)) {
        showStatus("请先打开财资云登录页，再点击“填写当前页面”。", "error");
        return;
      }

      try {
        const result = await chrome.tabs.sendMessage(tab.id, { type: MESSAGE.FILL_NOW });
        showFillResult(result);
      } catch {
        showStatus("请刷新登录页后再试。", "error");
      }
    } catch {
      showStatus("无法读取当前页面，请关闭弹窗后重试。", "error");
    } finally {
      setBusy(false);
    }
  });

  openLogin.href = LOGIN_URL;
  openLogin.addEventListener("click", async (event) => {
    event.preventDefault();
    try {
      await chrome.tabs.create({ url: LOGIN_URL });
    } catch {
      showStatus("无法打开登录页，请稍后重试。", "error");
    }
  });

  clearButton.addEventListener("click", () => {
    if (!ready || busy || !hasSavedSettings) return;
    clearButton.hidden = true;
    confirmation.hidden = false;
    cancelClear.focus();
  });

  cancelClear.addEventListener("click", () => {
    hideConfirmation();
    clearButton.focus();
  });

  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && !confirmation.hidden && !busy) {
      event.preventDefault();
      event.stopPropagation();
      hideConfirmation();
      clearButton.focus();
    }
  });

  confirmClear.addEventListener("click", async () => {
    if (!ready || busy || !hasSavedSettings) return;
    setBusy(true);
    showStatus("正在清除…");
    let cleared = false;
    try {
      await chrome.storage.local.remove(STORAGE_KEY);
      savedSettings = normalizeSettings(undefined);
      hasSavedSettings = false;
      writeForm(savedSettings);
      clearFieldErrors();
      hideConfirmation();
      showStatus("已清除本机保存的信息。", "success");
      cleared = true;
    } catch {
      showStatus("清除失败，请稍后重试。", "error");
    } finally {
      setBusy(false);
      if (cleared) enterpriseId.focus();
    }
  });

  loadSettings();
})();
