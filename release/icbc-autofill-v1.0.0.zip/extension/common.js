(() => {
  "use strict";

  const DEFAULT_SETTINGS = Object.freeze({
    enterpriseId: "",
    username: "",
    password: "",
    enabled: true,
  });

  function normalizeSettings(value) {
    const source = value && typeof value === "object" ? value : {};
    return {
      enterpriseId: typeof source.enterpriseId === "string" ? source.enterpriseId.trim() : "",
      username: typeof source.username === "string" ? source.username.trim() : "",
      // Passwords are opaque; never trim, log, or interpolate them into markup.
      password: typeof source.password === "string" ? source.password : "",
      enabled: source.enabled !== false,
    };
  }

  function validateSettings(value) {
    const settings = normalizeSettings(value);
    if (!settings.enterpriseId) return "请输入企业编号。";
    if (settings.enterpriseId.length > 8) return "企业编号最多为 8 位。";
    if (!settings.username) return "请输入账号。";
    if (!settings.password) return "请输入密码。";
    return null;
  }

  function isLoginUrl(value) {
    try {
      const url = new URL(value);
      return url.origin === "https://toc.icbc.com.cn"
        && url.pathname === "/login.html"
        && !url.username && !url.password
        && (url.hash === "" || /^#\/login\/?(?:\?.*)?$/.test(url.hash));
    } catch {
      return false;
    }
  }

  globalThis.ICBCAutofill = Object.freeze({
    LOGIN_URL: "https://toc.icbc.com.cn/login.html#/login",
    LOGIN_MATCH: "https://toc.icbc.com.cn/login.html*",
    STORAGE_KEY: "defaultProfile",
    DEFAULT_SETTINGS,
    MESSAGE: Object.freeze({
      FILL_NOW: "icbc:fill-now",
    }),
    normalizeSettings,
    validateSettings,
    isLoginUrl,
  });
})();
