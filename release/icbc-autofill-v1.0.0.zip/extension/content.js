(() => {
  "use strict";

  if (window.top !== window) return;
  const { STORAGE_KEY, MESSAGE, isLoginUrl, normalizeSettings, validateSettings } = ICBCAutofill;
  const SELECTORS = {
    enterpriseId: 'input[placeholder="请输入企业编号"]',
    username: 'input[placeholder="请输入用户名"]',
    password: '.ComPasswordInput input[placeholder="请输入登录密码"]',
  };
  const INPUT_SELECTOR = Object.values(SELECTORS).join(",");
  const valueSetter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value").set;
  let edited = new WeakSet();
  let filled = new WeakSet();
  let revision = 0;
  let editRevision = 0;
  let timer;
  let queue = Promise.resolve();

  function visibleInput(selector) {
    return Array.from(document.querySelectorAll(selector)).find((input) => {
      const style = getComputedStyle(input);
      return !input.disabled && !input.readOnly && input.getClientRects().length > 0
        && style.visibility !== "hidden" && style.visibility !== "collapse";
    });
  }

  function findFields() {
    const fields = Object.fromEntries(Object.entries(SELECTORS).map(([key, selector]) => [key, visibleInput(selector)]));
    return Object.values(fields).every(Boolean) ? fields : null;
  }

  function sameFields(fields) {
    const current = findFields();
    return current && Object.keys(SELECTORS).every((key) => current[key] === fields[key]);
  }

  function wasEdited(fields) {
    return Object.values(fields).some((input) => edited.has(input));
  }

  function writeInput(input, value, dispatchChange = true) {
    valueSetter.call(input, value);
    // The site's password component uses selectionStart to reconstruct its real value.
    if (input.type === "text" || input.type === "password") {
      input.setSelectionRange(value.length, value.length);
    }
    input.dispatchEvent(new Event("input", { bubbles: true, composed: true }));
    if (dispatchChange) input.dispatchEvent(new Event("change", { bubbles: true }));
  }

  const nextRender = () => new Promise((resolve) => setTimeout(resolve, 0));

  async function fill(manual, requestedEditRevision) {
    if (!isLoginUrl(location.href)) return { ok: false, status: "wrong-page" };
    if (editRevision !== requestedEditRevision) return { ok: false, status: "user-edited" };
    const fields = findFields();
    if (!fields) return { ok: false, status: "missing-fields" };
    if (!manual && filled.has(fields.password)) return { ok: true, status: "already-filled" };
    if (!manual && wasEdited(fields)) return { ok: false, status: "user-edited" };

    const startRevision = revision;
    let settings;
    try {
      const stored = await chrome.storage.local.get(STORAGE_KEY);
      settings = normalizeSettings(stored[STORAGE_KEY]);
    } catch {
      return { ok: false, status: "storage-error" };
    }
    if (validateSettings(settings)) return { ok: false, status: "unconfigured" };
    if (!settings.enabled && !manual) return { ok: false, status: "disabled" };

    function stillCurrent() {
      return revision === startRevision && isLoginUrl(location.href) && sameFields(fields)
        && editRevision === requestedEditRevision && (manual || !wasEdited(fields));
    }

    function identityMatches() {
      return fields.enterpriseId.value === settings.enterpriseId && fields.username.value === settings.username;
    }

    if (!stillCurrent()) return { ok: false, status: "user-edited" };
    if (!manual) {
      // A remembered company alone can be replaced by the chosen default. Never mix
      // a saved password into a different account or overwrite an existing password.
      const username = fields.username.value;
      const company = fields.enterpriseId.value;
      if (fields.password.value || (username && username !== settings.username)
        || (username && company && company !== settings.enterpriseId)) {
        return { ok: false, status: "conflict" };
      }
    }

    try {
      writeInput(fields.enterpriseId, settings.enterpriseId);
      writeInput(fields.username, settings.username);
      await nextRender();
      if (!stillCurrent()) return { ok: false, status: "user-edited" };
      if (!identityMatches()) return { ok: false, status: "conflict" };

      // Reset the old real value as well as the displayed asterisks before replacing
      // a masked password. Do not send a synchronous change event for this component.
      writeInput(fields.password, "", false);
      await nextRender();
      if (!stillCurrent()) return { ok: false, status: "user-edited" };
      if (!identityMatches()) return { ok: false, status: "conflict" };
      writeInput(fields.password, settings.password, false);
      filled.add(fields.password);
      await nextRender();
      return { ok: true, status: "filled" };
    } catch {
      return { ok: false, status: "missing-fields" };
    }
  }

  function enqueue(manual) {
    const requestedEditRevision = editRevision;
    const result = queue.then(() => fill(manual, requestedEditRevision));
    queue = result.catch(() => {});
    return result;
  }

  function schedule() {
    clearTimeout(timer);
    timer = setTimeout(() => { enqueue(false).catch(() => {}); }, 100);
  }

  // Only real user/browser input counts as an edit; our synthetic input must still
  // reach Vue while leaving the automatic-fill guard intact.
  function trackEdit(event) {
    if (event.isTrusted && event.target instanceof HTMLInputElement && event.target.matches(INPUT_SELECTOR)) {
      edited.add(event.target);
      editRevision += 1;
    }
  }
  document.addEventListener("beforeinput", trackEdit, true);
  document.addEventListener("input", trackEdit, true);

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (sender.id !== chrome.runtime.id) return false;
    if (message?.type === MESSAGE.FILL_NOW) {
      enqueue(true).then(sendResponse, () => sendResponse({ ok: false, status: "storage-error" }));
      return true;
    }
    return false;
  });

  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName === "local" && Object.hasOwn(changes, STORAGE_KEY)) {
      revision += 1;
      filled = new WeakSet();
      schedule();
    }
  });

  const observer = new MutationObserver(schedule);
  observer.observe(document, {
    childList: true,
    subtree: true,
    attributes: true,
    attributeFilter: ["class", "style", "disabled", "readonly"],
  });
  window.addEventListener("hashchange", () => {
    revision += 1;
    edited = new WeakSet();
    filled = new WeakSet();
    schedule();
  });
  window.addEventListener("pageshow", schedule);
  schedule();
})();
